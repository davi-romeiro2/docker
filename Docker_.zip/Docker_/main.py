from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
import requests
import urllib.parse

app = FastAPI()
templates = Jinja2Templates(directory="templates")

@app.get("/")
def form(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/clima")
def clima(request: Request, cidade: str):
    cidade_encoded = urllib.parse.quote(cidade)
    url = f"https://api.open-meteo.com/v1/forecast?latitude=-23.55&longitude=-46.63&current_weather=true"
    resposta = requests.get(url)
    dados = resposta.json()
    clima = dados["current_weather"]
    return templates.TemplateResponse("index.html", {
        "request": request,
        "cidade": cidade,
        "temperatura": clima["temperature"],
        "vento": clima["windspeed"]
    })
